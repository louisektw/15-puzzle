var gameboard = $("<div></div>");
var width = 400;
var height = width;
var gameSize = 4;
var tileMargin = 5;
var noOfMoves = 0;
var numberOfTiles = gameSize * gameSize - 1;
var data = [];


//generates the board for the game
function generateGameboard() {
  gameboard.addClass("gameboard");
  gameboard.width(width).height(height);
  $("body").append(gameboard);
}


//generates the tiles to the board
function generateTiles() {
  var tileWidth = (width - tileMargin * (gameSize + 1)) / gameSize;
  var tileHeight = (height - tileMargin * (gameSize + 1)) / gameSize;
  for (var j = 0; j < gameSize; j++) {
    data.push([]);
  }

  //shuffle the tiles
  var tilesInArray = shuffle(numberOfTiles);

  //then add the tiles to gameboard
  for (var i = 0; i < numberOfTiles; i++) {
    var tile = $("<div>" + (tilesInArray[i]) + "</div>");
    gameboard.append(tile);
    tile.addClass("tiles");
    tile.width(tileWidth).height(tileHeight);
    tile.css("font-size", Math.floor(tileHeight * 2 / 3) + "px");
    tile.css("line-height", tileHeight + "px");

    var col = i % gameSize;
    var row = Math.floor(i / gameSize);
    positionTiles(tile, col, row, false);

    data[row].push(tilesInArray[i]);
  }
  data[gameSize - 1].push(0);
}


//creates an array in order from 1-numberOfArray
function shuffle(numberOfTiles) {
  var arr = Array(numberOfTiles);
  for (var i = 0; i < arr.length; i++) {
    arr[i] = i + 1;
  }
  //then shuffle them
  for (let i = arr.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * i);
    var temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
  }
  //return shuffled array
  return arr;
}

//positioning of the tiles onto the board
function positionTiles(tile, col, row, smooth) {
  var x = col * (tile.width() + tileMargin) + tileMargin;
  var y = row * (tile.height() + tileMargin) + tileMargin;
  if (!smooth) {
    tile.css("left", x)
    tile.css("top", y)
  } else tile.animate({
    left: x,
    top: y
  }, 200);

  if (isWinner()) {
    setTimeout(function() {
      animateWinner();
    }, 300);
  }
}

//animates a flash if winner
function animateWinner() {
  $(".tiles").fadeOut(100).fadeIn(100).fadeOut(100).fadeIn(100);
  $("p").after("<h1>Congratulations, you won!</h1>");
}

//checks if tile is clicked
function tileClicked(event) {
  var tile = $(event.currentTarget);
  var value = parseInt(tile.text());
  var x, y;

  outer:
    for (var y = 0; y < gameSize; y++) {
      for (var x = 0; x < gameSize; x++) {
        if (data[y][x] == value) {
          break outer;
        }
      }
    }
  moveTile(tile, x, y);
}

//move the tile to the empty space.
//checks so not out of bounds.
function moveTile(tile, col, row) {
  var dx = 0;
  var dy = 0;


  if (col > 0 && data[row][col - 1] == 0) {
    dx = -1;
  } else if (col < gameSize - 1 && data[row][col + 1] == 0) {
    dx = 1;
  } else if (row > 0 && data[row - 1][col] == 0) {
    dy = -1;
  } else if (row < gameSize - 1 && data[row + 1][col] == 0) {
    dy = 1;
  } else {
    return;
  }

  var value = data[row][col];
  data[row + dy][col + dx] = value;
  data[row][col] = 0;
  positionTiles(tile, col + dx, row + dy, true);

  //increase the counter of moves
  $("#noOfMoves").html(++noOfMoves);
}

//checks if all tiles are in order which = winner
function isWinner() {
  var count = 1;
  for (var i = 0; i < gameSize; i++) {
    for (var j = 0; j < gameSize; j++) {
      if (data[i][j] != count) {
        if (!(count === (numberOfTiles + 1) && data[i][j] === 0)) {
          return false;
        }
      }
      count++;
    }
  }
  return true;
}


//starts the game
generateGameboard();
generateTiles();
$(".tiles").click(tileClicked);

//adds the shuffle button and shuffles the tiles when clicked
$(".gameboard").after('<button class="button" id="shuffle-btn" type="button">Shuffle</button>');
$("#shuffle-btn").click(function() {
  $(".tiles").remove();
  generateTiles();
});
